using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Threading;

namespace Haack.Threading
{
	/// <summary>
	/// Class provides a nice way of obtaining a lock that will time out 
	/// with a cleaner syntax than using the whole Monitor.TryEnter() method.
	/// </summary>
	/// <remarks>
	/// Adapted from Ian Griffiths article http://www.interact-sw.co.uk/iangblog/2004/03/23/locking
	/// </remarks>
	/// <example>
	/// Instead of:
	/// <code>
	/// lock(obj)
	/// {
	///		//Thread safe operation
	/// }
	/// 
	/// do this:
	/// 
	/// using(TimedLock.Lock(obj))
	/// {
	///		//Thread safe operations
	/// }
	/// 
	/// or this:
	/// 
	/// try
	/// {
	///		TimedLock timeLock = TimedLock.Lock(obj);
	///		//Thread safe operations
	///		timeLock.Dispose();
	/// }
	/// catch(LockTimeoutException)
	/// {
	///		Console.WriteLine("Couldn't get a lock!");
	/// }
	/// </code>
	/// </example>
#if DEBUG
	public class TimedLock : IDisposable
#else
	public struct TimedLock : IDisposable
#endif
	{
#if DEBUG
		static Hashtable _stackTraces = new Hashtable();
#endif
		object _target;

		/// <summary>
		/// Attempts to get a lock on an object.  Times out in the specified 
		/// timespan.
		/// </summary>
		/// <param name="o">object to lock</param>
		/// <param name="timeout">lock timeout</param>
		/// <returns></returns>
		/// <exception cref="LockTimeoutException">Thrown if the lock times out.</exception>
		public static TimedLock Lock(object o)
		{
			return Lock(o, 10);
		}

		/// <summary>
		/// Attempts to get a lock on an object.  Times out in the specified 
		/// amount of seconds.
		/// </summary>
		/// <param name="o">object to lock</param>
		/// <param name="timeoutInSeconds">lock timeout in seconds</param>
		/// <returns></returns>
		/// <exception cref="LockTimeoutException">Thrown if the lock times out.</exception>
		public static TimedLock Lock(object o, int timeoutInSeconds)
		{
			return Lock(o, TimeSpan.FromSeconds(timeoutInSeconds));
		}

		/// <summary>
		/// Attempts to get a lock on an object.  Times out in the specified 
		/// timespan.
		/// </summary>
		/// <param name="o">object to lock</param>
		/// <param name="timeout">lock timeout</param>
		/// <returns></returns>
		/// <exception cref="LockTimeoutException">Thrown if the lock times out.</exception>
		public static TimedLock Lock(object o, TimeSpan timeout)
		{
			TimedLock timedLock = new TimedLock(o);
			if(!Monitor.TryEnter(o, timeout))
			{
#if DEBUG
				System.GC.SuppressFinalize(timedLock);
				StackTrace blockingTrace = _stackTraces[o] as StackTrace;
				_stackTraces.Remove(o);
				throw new LockTimeoutException(blockingTrace);
#else
				throw new LockTimeoutException();
#endif
			}

#if DEBUG
			//Lock acquired. Store the stack trace.
			StackTrace trace = new StackTrace();
			lock(_stackTraces)
			{
				_stackTraces.Add(o, trace);
			}
#endif
			return timedLock;
		}

		/// Private constructor.  We don't want this object creatable.
		private TimedLock(object o)
		{
			_target = o;
		}	

		/// <summary>
		/// Exits the Monitor.  This MUST be called or you will 
		/// run into problems.
		/// </summary>
		public void Dispose()
		{
			Monitor.Exit(_target);
			lock(_stackTraces)
			{
				_stackTraces.Remove(_target);
			}
		}

#if DEBUG
		~TimedLock()
		{
			// If this finalizer runs, someone somewhere failed to
			// call Dispose, which means we've failed to leave
			// a monitor!
			System.Diagnostics.Debug.Fail("Undisposed lock");
		}
#endif

	}
	
	/// <summary>
	/// Thrown when a lock times out.
	/// </summary>
	[Serializable]
	public class LockTimeoutException : ApplicationException
	{
		public LockTimeoutException() : base("Timeout waiting for lock")
		{
		}

#if DEBUG
		StackTrace _blockingStackTrace = null;

		public StackTrace BlockingStackTrace
		{
			get
			{
				return _blockingStackTrace;
			}
		}

		public LockTimeoutException(StackTrace blockingStackTrace) : base()
		{
			_blockingStackTrace = blockingStackTrace;
		}
#endif

		public LockTimeoutException(string message) : base(message)
		{}
		
		public LockTimeoutException(string message, Exception innerException) : base(message, innerException)
		{}

		protected LockTimeoutException(SerializationInfo info, StreamingContext context) : base(info, context)
		{}
	}
}