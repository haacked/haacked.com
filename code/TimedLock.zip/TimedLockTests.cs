using System;
using System.Diagnostics;
using NUnit.Framework;
using System.Threading;
using Haack.Threading;

namespace UnitTests.Haack.Threading
{
	/// <summary>
	/// Unit tests for the GU.Core.Threading.TimedLock class.
	/// </summary>
	[TestFixture]
	public class TimedLockTests
	{
		object _lockedObject;

		/// <summary>
		/// Tests that a lock timeout is thrown when contention for a lock occurrs 
		/// and the timeout expires.
		/// </summary>
		[Test, ExpectedException(typeof(LockTimeoutException))]
		#region public void TestLockTimeout()
		public void TestLockTimeout()
		{
			_lockedObject = new object();

			//Spawn a thread that grabs and holds a lock on _lockedObject.
			Thread blockingThread = new Thread(new ThreadStart(HoldLock));
			blockingThread.Start();
			
			//Wait till thread is alive.
			while(!blockingThread.IsAlive)
			{
				Thread.Sleep(1);
			}

			//Give time for the thread to acquire the lock.
			Thread.Sleep(100);

			//Tries to get a lock for one second
			using(TimedLock.Lock(_lockedObject, TimeSpan.FromSeconds(1)))
			{
				Assertion.Fail("We should not be here.");
			}
		}
		#endregion

		/// <summary>
		/// Tests the DEBUG version of the TimedLock component. 
		/// This version throws a LockTimeoutException with a stack trace. 
		/// The test makes sure the stack trace exists, and then walks 
		/// up the stack to make sure the root is the HoldMethod.
		/// </summary>
		[Test]
		#region public void TestDebugLockTimeoutWithStackTrace()
		public void TestDebugLockTimeoutWithStackTrace()
		{
			_lockedObject = new object();

			//Spawn a thread that grabs and holds a lock on _lockedObject.
			Thread blockingThread = new Thread(new ThreadStart(HoldLock));
			blockingThread.Start();
			
			//Wait till thread is alive.
			while(!blockingThread.IsAlive)
			{
				Thread.Sleep(1);
			}

			//Give time for the thread to acquire the lock.
			Thread.Sleep(100);

			//Tries to get a lock for one second
			TimedLock timedLock = null;
			try
			{
				timedLock = TimedLock.Lock(_lockedObject, TimeSpan.FromSeconds(1));
			}
			catch(LockTimeoutException exc)
			{
				Assertion.AssertNotNull("Like WMDs, the method who locked this object cannot be found.", exc.BlockingStackTrace);
				StackFrame rootFrame = exc.BlockingStackTrace.GetFrame(exc.BlockingStackTrace.FrameCount - 1);
				Assertion.AssertEquals("I swear that HoldLock has the lock on this guy.", "HoldLock", rootFrame.GetMethod().Name);		
			}
			finally
			{
				if(timedLock != null)
				{
					timedLock.Dispose();
				}
			}
		}
		#endregion

		private void HoldLock()
		{
			//Get and hold a lock for a few seconds.
			using(TimedLock.Lock(_lockedObject))
			{
				for(int i = 0; i < 3; i++)
				{
					int j = _lockedObject.GetHashCode();
					Thread.Sleep(1000);
				}
			}
		}
	}
}
