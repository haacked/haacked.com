function Velocit_UpdatePairedDropDown(dropDown, paired, isSmaller)
{
	var pairedControl = document.getElementById(paired); 
	
	if(pairedControl != null)
	{
		if(isSmaller)
		{
			if(Velocit_CompareDropDowns(dropDown, pairedControl) > 0)
			{
				Velocit_MakePairedLarger(dropDown.selectedIndex, pairedControl);
			}
					
			// Assumes the larger will come after the smaller.
			// So focus is given to the larger after changing the smaller.
			pairedControl.focus();
		}
		else
		{
			if(Velocit_CompareDropDowns(dropDown, pairedControl) < 0)
			{
				Velocit_MakePairedSmaller(dropDown.selectedIndex, pairedControl);
			}
			
			// Assumes the larger will come after the smaller.
			// So focus is NOT given to the smaller after changing the larger.
		}
	}
}

// Returns -1 if the first drop down is smaller than the 
// paired.  Returns 1 if the first drop down is bigger than 
// the paired. Returns 0 if they're the same.  
// For now, does a selected index comparison, but this method 
// could be changed to do any type of comparison.
function Velocit_CompareDropDowns(dropDown, pairedDropDown)
{
	if(dropDown.selectedIndex < pairedDropDown.selectedIndex)
	{
		return -1;
	}
	else if(dropDown.selectedIndex > pairedDropDown.selectedIndex)
	{
		return 1;
	}
	else
	{
		return 0;
	}	
}

function Velocit_MakePairedLarger(index, pairedControl)
{
	if(pairedControl.options.length > index + 1)
	{
		pairedControl.selectedIndex = index + 1;
	}
	else
	{
		pairedControl.selectedIndex = index;
	}
}

function Velocit_MakePairedSmaller(index, pairedControl)
{
	if(index > 0)
	{
		pairedControl.selectedIndex = index - 1;
	}
	else
	{
		pairedControl.selectedIndex = index;
	}
}

