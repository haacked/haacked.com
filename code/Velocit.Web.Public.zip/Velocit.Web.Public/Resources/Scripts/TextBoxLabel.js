function TextBoxLabel_fillLabel(element)
{
	if(element.value == '')
	{
		if(element.attributes['Label'])
		{		
			element.value = element.attributes['Label'].value;
		}
	}
}

function TextBoxLabel_selectLabel(element)
{
	if(element.attributes['Label'])
	{
		if(element.value == element.attributes['Label'].value)
		{
			element.select();
		}
	}
}

function TextBoxLabel_clearLabel(element)
{
	if(element.attributes['Label'])
	{
		if(element.value == element.attributes['Label'].value)
		{
			element.value = '';
		}
	}
}

/*
If the element is empty hides the element and shows the 
label element.
*/
function TextBoxLabel_showPasswordLabel(passwordElement, labelElement)
{
	if(passwordElement.value == '')
	{
		if(passwordElement.attributes['Label'])
		{		
			passwordElement.style.display = 'none';
			labelElement.style.display = 'inline';
		}
	}
}

function TextBoxLabel_showPasswordInput(element, passwordElement)
{
	element.style.display = 'none';
	passwordElement.style.display = 'inline';
	passwordElement.value = '';
	passwordElement.focus();
}