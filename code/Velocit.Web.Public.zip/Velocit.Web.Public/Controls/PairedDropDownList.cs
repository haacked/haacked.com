using System;
using System.ComponentModel;
using System.Web.UI.WebControls;
using Velocit.Text;

namespace Velocit.Web.Controls
{
	/// <summary>
	/// Used to display decimal rates with an increment.
	/// </summary>
	public class PairedDropDownList : DropDownList
	{
		/// <summary>
		/// Gets or sets a control to pair with this control.  
		/// This control will make sure the paired control 
		/// is larger than itself via javascript.
		/// </summary>
		/// <value></value>
		[
		Browsable(true),
		Bindable(true),
		Category("Behavior"),
		DefaultValue(null),
		Description("If this dropdown represents a min value, it will ensure that the PairedControl is always larger.")
		]
		public string PairedControl
		{
			get
			{
				if (ViewState["PairedControl"] != null)
					return (string)ViewState["PairedControl"];
				return null;
			}
			set
			{
				ViewState["PairedControl"] = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether [is smaller of paired] controls.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if [is smaller of paired]; otherwise, <c>false</c>.
		/// </value>
		[
		Browsable(true),
		Bindable(true),
		Category("Behavior"),
		DefaultValue(null),
		Description("If this control is paired with another, returns whether this is the smaller or the larger.")
		]
		public bool IsSmallerOfPaired
		{
			get
			{
				if (ViewState["IsSmallerOfPaired"] != null)
					return (bool)ViewState["IsSmallerOfPaired"];
				return true;
			}
			set { ViewState["IsSmallerOfPaired"] = value; }
		}

		/// <summary>
		/// Registers the javascript used to pair the controls.
		/// </summary>
		/// <param name="e">E.</param>
		protected override void OnPreRender(EventArgs e)
		{
			if(!Page.IsClientScriptBlockRegistered("PairedDropDownHandler"))
			{
				Page.RegisterClientScriptBlock("PairedDropDownHandler", ScriptHelper.UnpackScript("PairedDropDown.js"));
			}

			if(PairedControl != null)
			{
				if(StringHelper.AreEqualIgnoringCase(PairedControl, this.ID))
					throw new ArgumentException("A Control cannot be paired with itself.", "PairedControl");

				PairedDropDownList pairedDropDown = Page.FindControl(PairedControl) as PairedDropDownList;

				if(pairedDropDown == null)
					throw new ArgumentException("The PairedControl '" + PairedControl + "' cannot be found.", "PairedControl");

				if(pairedDropDown.IsSmallerOfPaired == this.IsSmallerOfPaired)
					throw new ArgumentException("This control is paired with the control '" + this.PairedControl + "' that has the same value for 'IsSmallerOfPaired'.", "IsSmallerOfPaired");

				this.Attributes["onchange"] = "Velocit_UpdatePairedDropDown(this, '" + pairedDropDown.ClientID + "', " + this.IsSmallerOfPaired.ToString().ToLower() + ");";
			
			}
			
			base.OnPreRender(e);
		}
	}
}
