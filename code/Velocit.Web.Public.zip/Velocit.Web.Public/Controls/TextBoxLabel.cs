using System;
using System.ComponentModel;
using System.Web.UI.WebControls;

namespace Velocit.Web.Controls
{
	/// <summary>
	/// A Textbox control with special handling so it can act as a label.  
	/// When setting the label, the textbox displays the label within 
	/// the textbox until the user starts typing in the textbox.
	/// </summary>
	public class TextBoxLabel : TextBox
	{
		TextBox _labelTextBox = null; //Used for password text boxes.

		/// <summary>
		/// Initializes a new instance of the <see cref="TextBoxLabel"/> class.
		/// </summary>
		public TextBoxLabel() : base()
		{}

		/// <summary>
		/// Gets or sets the label.  The label is displayed when the textbox has 
		/// no other value.
		/// </summary>
		/// <value>The label.</value>
		[Browsable(true)]
		[Bindable(true)]
		[DefaultValue("")]
		[Category("Behavior")]
		public string Label
		{
			get { return this.Attributes["Label"] == null ? string.Empty : this.Attributes["Label"]; }
			set { this.Attributes["Label"] = value; }
		}

		/// <summary>
		/// Raises the <see cref="E:System.Web.UI.Control.Init"/>
		/// event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> object that contains the event data.</param>
		protected override void OnInit(EventArgs e)
		{
			if(this.TextMode == TextBoxMode.MultiLine)
				throw new NotSupportedException("The TextBoxLabel control does not support Multiline TextMode yet. Apologies.");

			if(!Page.IsClientScriptBlockRegistered("TextBoxLabel"))
			{
				Page.RegisterClientScriptBlock("TextBoxLabel", ScriptHelper.UnpackScript("TextBoxLabel.js"));
			}

			Page.RegisterOnSubmitStatement("TextBoxLabelPostBack__" + this.ClientID, "TextBoxLabel_clearLabel(document.getElementById('" + this.ClientID + "'));");
			
			if(this.TextMode == TextBoxMode.Password)
			{
				this.Attributes["style"] = "display:none;";

				CreatePasswordLabelTextBox();

				this.Attributes["onblur"] = String.Format("TextBoxLabel_showPasswordLabel(this, document.getElementById('{0}'));", _labelTextBox.ClientID);	
				_labelTextBox.Attributes["onfocus"] = String.Format("TextBoxLabel_showPasswordInput(this, document.getElementById('{0}'));", this.ClientID);
				SetDefaultPasswordLabel(_labelTextBox);
			}
			else
			{
				SetDefaultLabel();
				this.Attributes["onblur"] = String.Format("TextBoxLabel_fillLabel(this);");	
				this.Attributes["onfocus"] = String.Format("TextBoxLabel_selectLabel(this);");
			}

			base.OnInit (e);
		}

		private void CreatePasswordLabelTextBox()
		{
			_labelTextBox = new TextBox();
			_labelTextBox.Columns = this.Columns;
			_labelTextBox.Rows = this.Rows;
			_labelTextBox.Width = this.Width;
			_labelTextBox.ID = this.ID + "__PasswordLabel";
			_labelTextBox.Attributes["style"] = "display:none;";
			_labelTextBox.Text = this.Label;
			_labelTextBox.CssClass = this.CssClass;
		}

		private void SetDefaultPasswordLabel(TextBox labelTextBox)
		{
			if(this.Text.Length == 0 && !Page.IsStartupScriptRegistered("TextBoxLabelStartup__" + this.ClientID))
			{
				Page.RegisterStartupScript("TextBoxLabelStartup__" + this.ClientID, "<script language=\"Javascript\">" 
					+ Environment.NewLine  
					+ String.Format("TextBoxLabel_showPasswordLabel(document.getElementById('{0}'), document.getElementById('{1}'));", this.ClientID, labelTextBox.ClientID)
					+ Environment.NewLine  
					+ "</script>");
			}
		}

		private void SetDefaultLabel()
		{
			if(this.Text.Length == 0 && !Page.IsStartupScriptRegistered("TextBoxLabelStartup__" + this.ClientID))
			{
				Page.RegisterStartupScript("TextBoxLabelStartup__" + this.ClientID, "<script language=\"Javascript\">" 
					+ Environment.NewLine  
					+ "TextBoxLabel_fillLabel(document.getElementById('" + this.ClientID + "'));" 
					+ Environment.NewLine  
					+ "</script>");
			}
		}

		/// <summary>
		/// Attaches the label to the "title" attribute of the textbox.
		/// </summary>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		protected override void OnPreRender(EventArgs e)
		{
			if(this.Attributes["title"] == null || this.Attributes["title"].Length == 0)
			{
				this.Attributes["title"] = this.Label;
				if(this._labelTextBox != null)
				{
					_labelTextBox.Attributes["title"] = this.Label;
				}
			}

			base.OnPreRender (e);
		}


		/// <summary>
		/// Renders this control and an optional label textbox if this 
		/// control is a password field.
		/// </summary>
		/// <param name="writer">The writer.</param>
		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			base.Render (writer);
			if(this._labelTextBox != null)
			{
				_labelTextBox.RenderControl(writer);
			}
		}
	}
}