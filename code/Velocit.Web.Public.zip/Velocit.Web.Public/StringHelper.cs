using System;
using System.Collections.Specialized;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Velocit.Text
{
	/// <summary>
	/// Static class with useful string manipulation methods.
	/// </summary>
	public sealed class StringHelper
	{
		private StringHelper()
		{
		}

		/// <summary>
		/// Compares the strings and returns true if they are equal.
		/// </summary>
		/// <param name="source">Source.</param>
		/// <param name="compared">Compared.</param>
		/// <param name="sensitivity">Case sensitivity</param>
		/// <returns></returns>
		public static bool AreEqual(string source, string compared, CaseSensitivity sensitivity)
		{
			return string.Compare(source, compared, (sensitivity == CaseSensitivity.None), CultureInfo.InvariantCulture) == 0;
		}

		/// <summary>
		/// Compares the strings and returns true if they are equal, ignoring case.
		/// </summary>
		/// <param name="source">Source.</param>
		/// <param name="compared">Compared.</param>
		/// <returns></returns>
		public static bool AreEqualIgnoringCase(string source, string compared)
		{
			return AreEqual(source, compared, CaseSensitivity.Sensitive);
		}

		/// <summary>
		/// Parses a camel cased or pascal cased string and returns an array 
		/// of the words within the string.
		/// </summary>
		/// <example>
		/// The string "PascalCasing" will return an array with two 
		/// elements, "Pascal" and "Casing".
		/// </example>
		/// <param name="source"></param>
		/// <returns></returns>
		public static string[] SplitUpperCase(string source)
		{
			if(source == null)
				return new string[] {}; //Return empty array.

			if(source.Length == 0)
				return new string[] {""};

			StringCollection words = new StringCollection();
			int wordStartIndex = 0;

			char[] letters = source.ToCharArray();
			// Skip the first letter. we don't care what case it is.
			for(int i = 1; i < letters.Length; i++)
			{
				if(char.IsUpper(letters[i]))
				{
					//Grab everything before the current index.
					words.Add(new String(letters, wordStartIndex, i - wordStartIndex));
					wordStartIndex = i;
				}
			}
			//We need to have the last word.
			words.Add(new String(letters, wordStartIndex, letters.Length - wordStartIndex)); 

			//Copy to a string array.
			string[] wordArray = new string[words.Count];
			words.CopyTo(wordArray, 0);
			return wordArray;
		}

		/// <summary>
		/// Parses a camel cased or pascal cased string and returns a new 
		/// string with spaces between the words in the string.
		/// </summary>
		/// <example>
		/// The string "PascalCasing" will return an array with two 
		/// elements, "Pascal" and "Casing".
		/// </example>
		/// <param name="source"></param>
		/// <returns></returns>
		public static string SplitUpperCaseToString(string source)
		{
			return string.Join(" ", SplitUpperCase(source));
		}

		/// <summary>
		/// Returns a string containing a specified number of characters from the left side of a string.
		/// </summary>
		/// <param name="str">Required. String expression from which the leftmost characters are returned.</param>
		/// <param name="length">Required. Integer greater than 0. Numeric expression 
		/// indicating how many characters to return. If 0, a zero-length string ("") 
		/// is returned. If greater than or equal to the number of characters in Str, 
		/// the entire string is returned. If str is null, this returns null.</param>
		/// <returns></returns>
		/// <exception cref="ArgumentOutOfRangeException">Thrown if length is less than 0</exception>
		/// <exception cref="NullReferenceException">Thrown if str is null.</exception>
		public static string Left(string str, int length)
		{
			if(length >= str.Length)
				return str;

			return str.Substring(0, length);
		}

		/// <summary>
		/// Returns a string containing a specified number of characters from the right side of a string.
		/// </summary>
		/// <param name="str">Required. String expression from which the rightmost characters are returned.</param>
		/// <param name="length">Required. Integer greater than 0. Numeric expression 
		/// indicating how many characters to return. If 0, a zero-length string ("") 
		/// is returned. If greater than or equal to the number of characters in Str, 
		/// the entire string is returned. If str is null, this returns null.</param>
		/// <returns></returns>
		/// <exception cref="ArgumentOutOfRangeException">Thrown if length is less than 0</exception>
		/// <exception cref="NullReferenceException">Thrown if str is null.</exception>
		public static string Right(string str, int length)
		{
			if(str == null)
				throw new NullReferenceException("Right cannot be evaluated on a null string.");

			if(length < 0)
				throw new ArgumentOutOfRangeException("length", length, "Length must not be negative.");
			
			if(str.Length == 0 || length == 0)
				return String.Empty;

			if(length >= str.Length)
				return str;

			return str.Substring(str.Length - length);
		}

		/// <summary>
		/// Returns a string containing every character within a string after the 
		/// first occurrence of another string.
		/// </summary>
		/// <param name="str">Required. String expression from which the rightmost characters are returned.</param>
		/// <param name="searchString">The string where the end of it marks the 
		/// characters to return.  If the string is not found, the whole string is 
		/// returned.</param>
		/// <returns></returns>
		/// <exception cref="NullReferenceException">Thrown if str or searchstring is null.</exception>
		public static string RightAfter(string str, string searchString)
		{
			return RightAfter(str, searchString, CaseSensitivity.Sensitive);
		}

		/// <summary>
		/// Returns a string containing every character within a string after the 
		/// first occurrence of another string.
		/// </summary>
		/// <param name="str">Required. String expression from which the rightmost characters are returned.</param>
		/// <param name="searchString">The string where the end of it marks the 
		/// characters to return.  If the string is not found, the whole string is 
		/// returned.</param>
		/// <param name="sensitivity">Default true: If true, uses case sensitive search.</param>
		/// <returns></returns>
		/// <exception cref="NullReferenceException">Thrown if str or searchstring is null.</exception>
		public static string RightAfter(string str, string searchString, CaseSensitivity sensitivity)
		{
			if(searchString == null)
				throw new NullReferenceException("Search string may not be null.");

			//Shortcut.
			if(searchString.Length > str.Length || searchString.Length == 0)
				return str;

			int searchIndex;

			if(sensitivity == CaseSensitivity.Sensitive)
				searchIndex = str.IndexOf(searchString, 0);
			else
				searchIndex = str.ToUpper(CultureInfo.InvariantCulture).IndexOf(searchString.ToUpper(CultureInfo.InvariantCulture), 0);
			
			if(searchIndex < 0)
				return str;

			return Right(str, str.Length - (searchIndex + searchString.Length));
		}

		/// <summary>
		/// Returns a string containing every character within a string before the 
		/// first occurrence of another string.
		/// </summary>
		/// <param name="str">Required. String expression from which the leftmost characters are returned.</param>
		/// <param name="searchString">The string where the beginning of it marks the 
		/// characters to return.  If the string is not found, the whole string is 
		/// returned.</param>
		/// <returns></returns>
		/// <exception cref="NullReferenceException">Thrown if str or searchstring is null.</exception>
		public static string LeftBefore(string str, string searchString)
		{
			return LeftBefore(str, searchString, CaseSensitivity.Sensitive);
		}

		/// <summary>
		/// Returns a string containing every character within a string before the 
		/// first occurrence of another string.
		/// </summary>
		/// <param name="str">Required. String expression from which the leftmost characters are returned.</param>
		/// <param name="searchString">The string where the beginning of it marks the 
		/// characters to return.  If the string is not found, the whole string is 
		/// returned.</param>
		/// <param name="sensitivity">Default true: If true, uses case sensitive search.</param>
		/// <returns></returns>
		/// <exception cref="NullReferenceException">Thrown if str or searchstring is null.</exception>
		public static string LeftBefore(string str, string searchString, CaseSensitivity sensitivity)
		{
			if(searchString == null)
				throw new NullReferenceException("Search string may not be null.");

			//Shortcut.
			if(searchString.Length > str.Length || searchString.Length == 0)
				return str;

			int searchIndex;
			if(sensitivity == CaseSensitivity.Sensitive)
				searchIndex = str.IndexOf(searchString, 0);
			else
				searchIndex = str.ToUpper(CultureInfo.InvariantCulture).IndexOf(searchString.ToUpper(CultureInfo.InvariantCulture), 0);

			if(searchIndex < 0)
				return str;

			return Left(str, searchIndex);
		}

		/// <summary>
		/// Returns true if the specified string to be searched starts with 
		/// the specified prefix in a culturally invariant manner.
		/// </summary>
		/// <param name="searched">The string to check its start.</param>
		/// <param name="prefix">The string to search for at the beginning of the searched string.</param>
		/// <param name="sensitivity">Case sensitivity.</param>
		/// <returns></returns>
		public static bool StartsWith(string searched, string prefix, CaseSensitivity sensitivity)
		{
			if(searched == null)
				throw new NullReferenceException("The searched string may not be null.");

			// If we're not ignoring the case, use the built in function. 
			// That's what it's there for.
			if(sensitivity == CaseSensitivity.Sensitive)
				return searched.StartsWith(prefix);

			if(prefix == null)
				throw new NullReferenceException("The prefix string may not be null.");

			if(prefix.Length > searched.Length)
				return false;

			string prefixSizedString = Left(searched, prefix.Length);
			return AreEqual(prefixSizedString, prefix, CaseSensitivity.None);
		}

		/// <summary>
		/// Returns true if the specified string to be searched ends with 
		/// the specified prefix in a culturally invariant manner.
		/// </summary>
		/// <param name="searched">The string to check its end.</param>
		/// <param name="suffix">The string to search for at the end of the searched string.</param>
		/// <param name="sensitivity">Ignore case.</param>
		/// <returns></returns>
		public static bool EndsWith(string searched, string suffix, CaseSensitivity sensitivity)
		{
			if(searched == null)
				throw new NullReferenceException("The searched string may not be null.");

			if(sensitivity == CaseSensitivity.Sensitive)
				return searched.EndsWith(suffix);

			if(suffix == null)
				throw new NullReferenceException("The prefix string may not be null.");

			if(suffix.Length > searched.Length)
				return false;

			string suffixSizedString = Right(searched, suffix.Length);
			return AreEqual(suffixSizedString, suffix, CaseSensitivity.None);
		}

		/// <summary>
		/// Returns the index of the first string within the second.
		/// </summary>
		/// <param name="container">Container.</param>
		/// <param name="contained">Contained.</param>
		/// <param name="sensitivity">Case sensitive.</param>
		/// <returns></returns>
		public static int IndexOf(string container, string contained, CaseSensitivity sensitivity)
		{
			if(sensitivity == CaseSensitivity.Sensitive)
				return container.IndexOf(contained);
			else
				return container.ToUpper(CultureInfo.InvariantCulture).IndexOf(contained.ToUpper(CultureInfo.InvariantCulture));
		}

		/// <summary>
		/// Determines whether one string contains the other.
		/// </summary>
		/// <param name="container">The container.</param>
		/// <param name="contained">The contained.</param>
		/// <param name="sensitivity">The sensitivity.</param>
		/// <returns>
		/// 	<c>true</c> if [contains] [the specified container]; otherwise, <c>false</c>.
		/// </returns>
		public static bool Contains(string container, string contained, CaseSensitivity sensitivity)
		{
			return IndexOf(container, contained, sensitivity) > -1;
		}

		/// <summary>
		/// Determines whether one string contains the other.
		/// </summary>
		/// <param name="container">The container.</param>
		/// <param name="contained">The contained.</param>
		/// <returns>
		/// 	<c>true</c> if [contains] [the specified container]; otherwise, <c>false</c>.
		/// </returns>
		public static bool Contains(string container, string contained)
		{
			return Contains(container, contained, CaseSensitivity.Sensitive);
		}

		/// <summary>
		/// Replaces the occurrence of one string with another.
		/// </summary>
		/// <param name="original">The original.</param>
		/// <param name="search">The search.</param>
		/// <param name="replace">The replace.</param>
		/// <param name="sensitivity">The sensitivity.</param>
		/// <returns></returns>
		public static string Replace(string original, string search, string replace, CaseSensitivity sensitivity)
		{
			RegexOptions options = RegexOptions.None;
			if(sensitivity == CaseSensitivity.Sensitive)
				options = RegexOptions.IgnoreCase;
			return Regex.Replace(original, search, Regex.Escape(replace), options);
		}
	}

	/// <summary>
	/// Used to indicate case sensitivity of string comparison.
	/// </summary>
	[Serializable]
	public enum CaseSensitivity
	{
		/// <summary>None</summary>
		None,
		/// <summary>Case Sensitive</summary>
		Sensitive
	}
}
