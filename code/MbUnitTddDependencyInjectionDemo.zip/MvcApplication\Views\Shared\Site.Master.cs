﻿using System;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication.Views.Layouts
{
    public partial class Site : System.Web.Mvc.ViewMasterPage
    {
    }
}
