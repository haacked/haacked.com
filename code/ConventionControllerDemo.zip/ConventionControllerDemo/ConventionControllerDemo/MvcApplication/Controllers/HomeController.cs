﻿using System;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication.Controllers
{
    public class HomeController : ConventionController
    {
        public void Index()
        {
        }

        public void About()
        {
        }
    }
}
