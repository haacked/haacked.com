﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Reflection;

namespace System.Web.Mvc
{
    public abstract class ConventionController : Controller
    {
        bool viewRendered = false;

        protected override bool InvokeAction(string actionName)
        {
            if (String.IsNullOrEmpty(actionName))
                throw new ArgumentNullException("actionName");

            MethodInfo actionMethodInfo = GetActionMethod(actionName);
                      
            if (actionMethodInfo == null)
                return false;

            InvokePreAndPostActions(actionName, actionMethodInfo);
            return true;
        }

        protected override void RenderView(string viewName, string masterName, object viewData)
        {
            this.viewRendered = true;
            base.RenderView(viewName, masterName, viewData);
        }

        private void InvokePreAndPostActions(string actionName, MethodInfo actionMethodInfo)
        {
            if (this.OnPreAction(actionName, actionMethodInfo))
            {
                try
                {
                    this.InvokeActionMethod(actionMethodInfo);
                    if (!this.viewRendered)
                    {
                        RenderView(actionName);
                    }
                }
                catch (Exception exception)
                {
                    if (this.OnError(actionName, actionMethodInfo, exception))
                    {
                        throw;
                    }
                }
                finally
                {
                    this.OnPostAction(actionName, actionMethodInfo);
                }
            }
        }

        private MethodInfo GetActionMethod(string actionName)
        {
            MethodInfo[] methods = base.GetType().GetMethods(BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Instance);
            MethodInfo actionMethodInfo = null;
            foreach (MethodInfo method in methods)
            {
                if (string.Equals(actionName, method.Name, StringComparison.OrdinalIgnoreCase))
                {
                    if (actionMethodInfo != null)
                        throw new InvalidOperationException(string.Format("More than one action of the same name, '{0}. LOCALIZE ME!'", actionName));
                    
                    actionMethodInfo = method;
                }
            }
            return actionMethodInfo;
        }
    }
}
