﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class HomeControllerTest
    {

        [TestMethod]
        public void About()
        {
            //
            // TODO: Add test logic	here
            //
        }

        [TestMethod]
        public void Index()
        {
            //
            // TODO: Add test logic	here
            //
        }
    }
}
