﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;

namespace MvcApplicationTest.Controllers
{
    [TestClass]
    public class ConventionControllerTests
    {
        [TestMethod]
        public void CanCallControllerMethodWithouControllerAction()
        {
            TestController controller = new TestController();
            controller.Foo(); //With a regular controller, this throws an exception.
        }

        [TestMethod]
        public void ViewGetsRenderedByDefault()
        {
            TestController controller = new TestController();
            controller.InvokeActionPublic("Foo");
            Assert.AreEqual("Foo", controller.ViewRendered, "Should have automatically selected view");
        }

        
    }

    internal class TestController : ConventionController
    {
        public void Foo()
        { 
        }

        protected override void RenderView(string viewName, string masterName, object viewData)
        {
            this.ViewRendered = viewName;
        }

        public string ViewRendered { get; private set; }

        public bool InvokeActionPublic(string actionName)
        {
            return base.InvokeAction(actionName);
        }
    }
}
