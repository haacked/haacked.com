﻿namespace IgnoreRouteWeb {
    using System.Web;

    public class ErrorHttpHandler : IHttpHandler {
        public bool IsReusable {
            get {
                return true;
            }
        }

        public void ProcessRequest(HttpContext context) {
            context.Response.Write("It Worked!");
        }
    }
}
