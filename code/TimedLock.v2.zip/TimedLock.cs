using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Threading;

namespace Haack.Threading
{
	/// <summary>
	/// Class provides a nice way of obtaining a lock that will time out 
	/// with a cleaner syntax than using the whole Monitor.TryEnter() method.
	/// </summary>
	/// <remarks>
	/// Adapted from Ian Griffiths article http://www.interact-sw.co.uk/iangblog/2004/03/23/locking
	/// </remarks>
	/// <example>
	/// Instead of:
	/// <code>
	/// lock(obj)
	/// {
	///		//Thread safe operation
	/// }
	/// 
	/// do this:
	/// 
	/// using(TimedLock.Lock(obj))
	/// {
	///		//Thread safe operations
	/// }
	/// 
	/// or this:
	/// 
	/// try
	/// {
	///		TimedLock timeLock = TimedLock.Lock(obj);
	///		//Thread safe operations
	///		timeLock.Dispose();
	/// }
	/// catch(LockTimeoutException)
	/// {
	///		Console.WriteLine("Couldn't get a lock!");
	/// }
	/// </code>
	/// </example>
	public struct TimedLock : IDisposable
	{
		public static TimedLock Lock (object o)
		{
			return Lock (o, TimeSpan.FromSeconds (10));
		}

		public static TimedLock Lock (object o, TimeSpan timeout)
		{
			TimedLock tl = new TimedLock (o);
			if (!Monitor.TryEnter(o, timeout))
			{
#if DEBUG
				System.GC.SuppressFinalize(tl.leakDetector);
				StackTrace blockingTrace = null;
				lock(Sentinel.StackTraces)
				{
					blockingTrace = Sentinel.StackTraces[o] as StackTrace;
				}
				throw new LockTimeoutException(blockingTrace);
#else
				throw new LockTimeoutException();
#endif
			}
#if DEBUG
			//Lock acquired. Store the stack trace.
			StackTrace trace = new StackTrace();
			lock(Sentinel.StackTraces)
			{
				Sentinel.StackTraces.Add(o, trace);
			}
#endif
			return tl;
		}

		private TimedLock (object o)
		{
			target = o;
#if DEBUG
			leakDetector = new Sentinel();
#endif
		}
		private object target;

		public void Dispose()
		{
			Monitor.Exit(target);

			// It's a bad error if someone forgets to call Dispose,
			// so in Debug builds, we put a finalizer in to detect
			// the error. If Dispose is called, we suppress the
			// finalizer.
#if DEBUG
			GC.SuppressFinalize(leakDetector);
			lock(Sentinel.StackTraces)
			{
				Sentinel.StackTraces.Remove(target);
			}
#endif
		}

#if DEBUG
		// (In Debug mode, we make it a class so that we can add a finalizer
		// in order to detect when the object is not freed.)
		private class Sentinel
		{
			public static Hashtable StackTraces = new Hashtable();
			
			~Sentinel()
			{
				// If this finalizer runs, someone somewhere failed to
				// call Dispose, which means we've failed to leave
				// a monitor!
				System.Diagnostics.Debug.Fail("Undisposed lock");
			}
		}
		private Sentinel leakDetector;
#endif

	}

	#region public class LockTimeoutException : ApplicationException
	/// <summary>
	/// Thrown when a lock times out.
	/// </summary>
	[Serializable]
	public class LockTimeoutException : ApplicationException
	{
		public LockTimeoutException() : base("Timeout waiting for lock")
		{
		}

#if DEBUG
		StackTrace _blockingStackTrace = null;

		public StackTrace BlockingStackTrace
		{
			get
			{
				return _blockingStackTrace;
			}
		}

		public LockTimeoutException(StackTrace blockingStackTrace) : base()
		{
			_blockingStackTrace = blockingStackTrace;
		}
#endif

		public LockTimeoutException(string message) : base(message)
		{}
		
		public LockTimeoutException(string message, Exception innerException) : base(message, innerException)
		{}

		protected LockTimeoutException(SerializationInfo info, StreamingContext context) : base(info, context)
		{}
	}
	#endregion
}