IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[FtpPutFile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[FtpPutFile]
GO

-- Created by Nigel Rivett.
-- http://www.nigelrivett.net/FTP/s_ftp_PutFile.html
CREATE PROCEDURE [dbo].[FtpPutFile]    
(    
	@FTPServer varchar(128)    
	, @FTPUser nvarchar(128)    
	, @FTPPWD  nvarchar(128)    
	, @FTPPath nvarchar(128)    
	, @FTPFileName nvarchar(128)    
	, @SourcePath nvarchar(128)    
	, @SourceFile nvarchar(128)    
	, @workdir nvarchar(128)    
	, @binaryFile bit = NULL    
)
AS
/*
exec FtpPutFile     
    @FTPServer = 'ftp.example.com' ,
    @FTPUser = n'username' ,
    @FTPPWD = n'password' ,
    @FTPPath = n'/dir1/' ,
    @FTPFileName = n'test2.txt' ,
    @SourcePath = n'c:\vss\mywebsite\' ,
    @SourceFile = n'MyFileName.html' ,
    @workdir = n'c:\temp\'
*/
   
IF(@binaryFile IS NULL)   
BEGIN   
  SET @binaryFile = 1    
END  
    
DECLARE @cmd varchar(1000)    
DECLARE @workfilename varchar(128)    
     
SELECT @workfilename = 'ftpcmd.txt'    
     
-- deal with special characters for echo commands    
SELECT @FTPServer = REPLACE(
	REPLACE(REPLACE(@FTPServer, '|', '^|'),'<','^<'),'>','^>')    
SELECT @FTPUser = REPLACE(
	REPLACE(REPLACE(@FTPUser, '|', '^|'),'<','^<'),'>','^>')    
SELECT @FTPPWD = REPLACE(
	REPLACE(REPLACE(@FTPPWD, '|', '^|'),'<','^<'),'>','^>')    
SELECT @FTPPath = REPLACE(
	REPLACE(REPLACE(@FTPPath, '|', '^|'),'<','^<'),'>','^>')    
 
SELECT @cmd = 'echo '     + 'open ' + @FTPServer + ' > ' + @workdir + @workfilename    
exec master..xp_cmdshell @cmd    
SELECT @cmd = 'echo '     + @FTPUser    
+ '>> ' + @workdir + @workfilename    
exec master..xp_cmdshell @cmd    
SELECT @cmd = 'echo '     + @FTPPWD    
+ '>> ' + @workdir + @workfilename    
exec master..xp_cmdshell @cmd    

IF @binaryFile = 1    
BEGIN    
	SELECT @cmd = 'echo '     + 'bin' + ' >> ' + @workdir + @workfilename    
	exec master..xp_cmdshell @cmd    
END    
 

SELECT @cmd = 'echo '     + 'put ' + @SourcePath + @SourceFile 
			+ ' ' + @FTPPath + @FTPFileName    
			+ ' >> ' + @workdir + @workfilename    
exec master..xp_cmdshell @cmd    
SELECT @cmd = 'echo '     + 'quit'    
				+ ' >> ' + @workdir + @workfilename    
exec master..xp_cmdshell @cmd    
 
SELECT @cmd = 'ftp -s:' + @workdir + @workfilename    
 
CREATE TABLE #a (id int identity(1,1), s varchar(1000))    
INSERT #a    
exec master..xp_cmdshell @cmd    
 
SELECT id, ouputtmp = s from #a    
GO




IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetRandomTimeOfDay]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[GetRandomTimeOfDay]
GO

USE [master]
GO

CREATE PROCEDURE [dbo].GetRandomTimeOfDay
( 
	@timeOfDay int = 0 OUTPUT -- Formatted as HHMMSS. 0 = Midnight
	, @maxHour int = 24 -- Upper bound for the hour of the day.
)
AS
BEGIN
	IF @maxHour > 24 OR @maxHour < 1
		RAISERROR ('Please choose a value between 1 and 24', 16, 1)   
	
	DECLARE @randomHours int
	SELECT @randomHours = 
		(@maxHour - 1) * RAND(CAST(CAST(newid() as binary(8)) as INT))
	
	DECLARE @randomMinutes int
	SELECT @randomMinutes = 
		60 * RAND(CAST(CAST(newid() as binary(8)) as INT))
	
	DECLARE @timeOfDayDate DateTime
	SET @timeOfDayDate = '00:00:00'
	
	SET @timeOfDayDate = DATEADD(hh, @randomHours, @timeOfDayDate)
	SET @timeOfDayDate = DATEADD(mi, @randomMinutes, @timeOfDayDate)
	
	DECLARE @timeAsString varchar(8)
	DECLARE @timeWithoutColons varchar(6)
	
	SET @timeAsString = CONVERT(varchar(8), @timeOfDayDate, 8)
	SET @timeWithoutColons = REPLACE(@timeAsString, ':', '')
	
	SET @timeOfDay = ( CAST(@timeWithoutColons as int) )
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CreateBackupJob]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CreateBackupJob]
GO

CREATE PROCEDURE CreateBackupJob  
(  
	@databaseName nvarchar(128)  
	, @jobname nvarchar(255) = NULL
	, @scheduleName nvarchar(255) = NULL
	, @timeOfDay int = -1 -- Negative value indicates generate random.
	, @maxHour int = 4 -- Maximum hour of the day in which the backup job can run.
	, @owner nvarchar(128) = N'sa'  
	, @backupDirectory nvarchar(256) = N'D:\Database\Backups'  
	, @ftpServer nvarchar(128)
	, @ftpUser nvarchar(128)
	, @ftpPassword nvarchar(128)
	, @ftpPath nvarchar(128) = N'/'  
	
)  
AS  
SET NOCOUNT ON  
BEGIN TRANSACTION               
	IF @databaseName = N''  
	BEGIN  
		RAISERROR ('Did not specify a database name', 16, 1)   
	END
	
	if @ftpServer = N''
	BEGIN
		RAISERROR ('Did not specify an ftp server', 16, 1)
	END
	
	if @ftpUser = N'' OR @ftpPassword = N''
	BEGIN
		RAISERROR ('Did not specify an ftp username or password', 16, 1)
	END
	
	IF @timeOfDay = -1
	BEGIN
		-- Randomly add some minutes and hours to midnight.
		exec GetRandomTimeOfDay @timeOfDay OUTPUT, 2
	END

	DECLARE @descr nvarchar(255)  
	DECLARE @jobcommand nvarchar(256)   
	DECLARE @ftpCommand nvarchar(512)  

 	IF(@jobname IS null OR @jobname = '')
		SET @jobname = N'Backup ' + @databaseName
	
	IF(@scheduleName IS null OR @scheduleName = '')
		SET @scheduleName = N'Every Night At ' + CAST(CAST(@timeOfDay as DateTime) as varchar(12))
	
	SET @descr = N'Takes a backup of ' + @databaseName + ' and ftp''s it to ' + @ftpServer    
	
	SET @jobcommand = N'BACKUP DATABASE [' + @databaseName + '] TO   
	  DISK = N''' + @backupDirectory + '\' + @databaseName + '.bak''   
	  WITH  NOINIT, NOUNLOAD,   
	  NAME = N''BACKUP ' + @databaseName + ''',   
	  NOSKIP, STATS = 10, NOFORMAT'  
   
	 SET @ftpCommand = N'EXEC FtpPutFile 
		@FTPServer=''' + @ftpServer + '''
		, @FTPUser=''' + @ftpUser + '''
		, @FTPPWD=''' + @ftpPassword + '''
		, @FTPPath=''' + @ftpPath + '''
		, @FTPFileName=''' + @databaseName + '.bak''
		, @SourcePath = ''' + @backupDirectory + '\''
		, @SourceFile=''' + @databaseName + '.bak''
		, @WorkDir=''C:\Windows\Temp\'''  
   
	DECLARE @JobID BINARY(16)    
	DECLARE @ReturnCode INT      
	SELECT @ReturnCode = 0       
	IF (SELECT COUNT(*) FROM msdb.dbo.syscategories WHERE name = N'[Uncategorized (Local)]') < 1   
		EXECUTE msdb.dbo.sp_add_category @name = N'[Uncategorized (Local)]'  
	
	-- Delete the job with the same name (if it exists)  
	SELECT @JobID = job_id       
	FROM   msdb.dbo.sysjobs      
	WHERE (name = N'Backup ' + @databaseName)         
	   
	IF (@JobID IS NOT NULL)      
	BEGIN    
		-- Check if the job is a multi-server job    
		IF (EXISTS (SELECT  *   
			FROM    msdb.dbo.sysjobservers   
			WHERE   (job_id = @JobID) AND (server_id <> 0)))   
		BEGIN   
			-- There is, so abort the script   
			DECLARE @errormsg nvarchar(255)  
			SET @errormsg = N'Unable to import job ''Backup ' + @databaseName + ''' since there is already a multi-server job with this name.'  
			RAISERROR (@errormsg, 16, 1)   
			GOTO QuitWithRollback    
		END   
	ELSE   
		-- Delete the [local] job   
		EXECUTE msdb.dbo.sp_delete_job @job_name = @jobname  
		SELECT @JobID = NULL  
	END   
	  
	BEGIN   
	   -- Add the job  
	EXECUTE @ReturnCode = msdb.dbo.sp_add_job @job_id = @JobID OUTPUT , @job_name = @jobname, @owner_login_name = @owner, @description = @descr, @category_name = N'[Uncategorized (Local)]', @enabled = 1, @notify_level_email = 0, @notify_level_page = 0, @notify_level_netsend = 0, @notify_level_eventlog = 2, @delete_level= 0  
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback   
	
	-- Add the job steps 
	
	-- DATABASE BACKUP 
	EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_id = @JobID, @step_id = 1, @step_name = @jobname, @command = @jobcommand, @database_name = N'master', @server = N'', @database_user_name = N'', @subsystem = N'TSQL', @cmdexec_success_code = 0, @flags = 0, @retry_attempts = 0, @retry_interval = 1, @output_file_name = N'', @on_success_step_id = 0, @on_success_action = 3, @on_fail_step_id = 0, @on_fail_action = 2  
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback   
	
	-- FTP BACKUP
	EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_id = @JobID, @step_id = 2, @step_name = N'FTP Database Backup', @command = @ftpCommand, @database_name = N'master', @server = N'', @database_user_name = N'', @subsystem = N'TSQL', @cmdexec_success_code =
	0, @flags = 0, @retry_attempts = 0, @retry_interval = 1, @output_file_name = N'', @on_success_step_id = 0, @on_success_action = 1, @on_fail_step_id = 0, @on_fail_action = 2  
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback   
	EXECUTE @ReturnCode = msdb.dbo.sp_update_job @job_id = @JobID, @start_step_id = 1   
	
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback   
	
	-- Add the job schedules  
	EXECUTE @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id = @JobID
		, @name = @scheduleName
		, @enabled = 1
		, @freq_type = 4 					--Daily
		, @active_start_date = 20060419		--In the past is fine.
		, @active_start_time = 0			--TIME OF DAY
		, @freq_interval = 1				--Not Used
		, @freq_subday_type = 1				--At the specified time
		, @freq_subday_interval = 0
		, @freq_relative_interval = 0
		, @freq_recurrence_factor = 0
		, @active_end_date = 99991231
		, @active_end_time = 235959  
	
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback   
	
	-- Add the Target Servers 
	EXECUTE @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @JobID, @server_name = N'(local)'   
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback   
	
	END  
COMMIT TRANSACTION            
GOTO   EndSave                
QuitWithRollback:  
IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION   
	EndSave:   
