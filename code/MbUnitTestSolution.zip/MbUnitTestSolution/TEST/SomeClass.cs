using System;

namespace TEST
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class SomeClass
	{
		public SomeClass()
		{
		}

		public int Add(int x, int y)
		{
			return x + y;
		}
	}
}
