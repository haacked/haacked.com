using System;
using MbUnit.Framework;
using TEST;

namespace UnitTests
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	[TestFixture]
	public class SomeClassTests
	{
		[Test]
		public void AddTests()
		{
			SomeClass calculator = new SomeClass();
			Assert.AreEqual(2, calculator.Add(1, 1), "Expected 1+1 to equal 2.");
		}
	}
}
