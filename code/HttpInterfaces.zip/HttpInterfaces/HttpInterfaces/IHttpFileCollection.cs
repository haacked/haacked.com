using System;
using System.Web;

namespace HttpInterfaces
{
	public interface IHttpFileCollection
	{
		HttpPostedFile Get(int index);
		HttpPostedFile Get(string name);
		string GetKey(int index);

		// Properties
		string[] AllKeys { get; }
		HttpPostedFile this[string name] { get; }
		HttpPostedFile this[int index] { get; }
	}
}
