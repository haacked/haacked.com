Duck Typing Library

Copyright (C) 2007 David Meyer
All Rights Reserved

Website: http://www.deftflux.net/
E-mail: deftflux@deftflux.net

This product is licensed to the public via Artistic License 2.0 which should be found in a file
named license.txt included with the package.  It is also available online at:
http://www.perlfoundation.org/artistic_license_2_0


NOTE: The dependent library NGenerics was not authored by David Meyer and is not covered by 
this license.  Go to http://www.codeplex.com/NGenerics for their license terms.