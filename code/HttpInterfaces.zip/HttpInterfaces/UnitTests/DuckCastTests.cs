using System;
using System.Web;
using HttpInterfaces;
using MbUnit.Framework;
using Subtext.TestLibrary;

namespace UnitTests
{
	[TestFixture]
	public class DuckTypeTests
	{
		[Test]
		public void CanCastHttpRequest()
		{
			using(HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx?s=true"));

				IHttpRequest request = WebContext.Cast(HttpContext.Current.Request);
				Assert.AreEqual("true", request["s"]);
			}
		}

		[Test]
		public void CanCastHttpResponse()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpResponse response = WebContext.Cast(HttpContext.Current.Response);
				Assert.IsNotNull(response);
			}
		}

		[Test]
		public void CanCastSession()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpSession session = WebContext.Cast(HttpContext.Current.Session);
				Assert.IsNotNull(session);
			}
		}

		[Test]
		public void CanCastServerUtility()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpServerUtility serverUtility = WebContext.Cast(HttpContext.Current.Server);
				Assert.IsNotNull(serverUtility);
			}
		}

		[Test]
		public void CanCastApplication()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpApplicationState application = WebContext.Cast(HttpContext.Current.Application);
				Assert.IsNotNull(application);
			}
		}

		[Test]
		public void CanCastCache()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				ICache cache = WebContext.Cast(HttpContext.Current.Cache);
				Assert.IsNotNull(cache);
			}
		}

		[Test]
		public void CanCastIHttpCachePolicy()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpCachePolicy cachePolicy = WebContext.Cast(HttpContext.Current.Response.Cache);
				Assert.IsNotNull(cachePolicy);
			}
		}

		[Test]
		public void CanCastIHttpClientCertificate()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpClientCertificate clientCertificate = WebContext.Cast(HttpContext.Current.Request.ClientCertificate);
				Assert.IsNotNull(clientCertificate);
			}
		}

		[Test]
		public void CanCastIHttpFileCollection()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpFileCollection files = WebContext.Cast(HttpContext.Current.Request.Files);
				Assert.IsNotNull(files);
			}
		}

		[Test]
		[Ignore("HttpSimulator doesn't seem to support ApplicationInstance.")]
		public void CanCastIHttpModuleCollection()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpModuleCollection files = WebContext.Cast(HttpContext.Current.ApplicationInstance.Modules);
				Assert.IsNotNull(files);
			}
		}

		[Test]
		[Ignore("HttpSimulator doesn't seem to support ApplicationInstance.")]
		public void CanCastApplicationInstance()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpApplication application = WebContext.Cast(HttpContext.Current.ApplicationInstance);
				Assert.IsNotNull(application);
			}
		}

		[Test]
		public void CanCastITraceContext()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				ITraceContext context = WebContext.Cast(HttpContext.Current.Trace);
				Assert.IsNotNull(context);
			}
		}

		[Test]
		public void CanCastHttpContext()
		{
			using (HttpSimulator simulator = new HttpSimulator())
			{
				simulator.SimulateRequest(new Uri("http://haacked.com/Test.aspx"));

				IHttpContext context = WebContext.Cast(HttpContext.Current);
				Assert.IsNotNull(context);
			}
		}
	}
}
