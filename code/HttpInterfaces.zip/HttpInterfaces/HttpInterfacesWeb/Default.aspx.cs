using System;
using System.Web;
using HttpInterfaces;

namespace HttpInterfacesWeb
{
	public partial class _Default : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			IHttpApplication appInstance = WebContext.Cast(HttpContext.Current.ApplicationInstance);
			Response.Write("appInstance != null is " + (appInstance != null) + "<br />");

			IHttpApplicationState application = WebContext.Cast(HttpContext.Current.Application);
			application["var"] = "AppVar";
			Response.Write("application[\"var\"] = " + application["var"] + "<br />");

			

			HelloWorld(appInstance.Response, "IHttpApplication.Response");
			HelloWorld(WebContext.Current.Response, "WebContext.Current.Response");
			HelloWorld(WebContext.Cast(Response), "WebContext.Cast(Response)");
			IHttpRequest request = WebContext.Cast(HttpContext.Current.Request);
			Response.Write(request.QueryString["s"] + "<br />");
		}

		public void HelloWorld(IHttpResponse response, string note)
		{
			response.Write(string.Format("<p>Hello World '{0}'</p>", note));
		}
	}
}
