using System;

namespace ConditionalCompilation
{
	public partial class _Default : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
#if FOO
			Response.Write("FOO Defined in web app code file!<br />");
#endif

#if BAR
			Response.Write("BAR Defined in web app code file!<br />");
#endif

#if CORGE
			Response.Write("CORGE Defined in web app code file!<br />");
#endif

		}
	}
}
