using System;
using System.Web;
using System.Drawing;
using System.Drawing.Imaging;
using System.Net;
using System.IO;
using Docuverse.Identicon;

/// <summary>
/// Productionized Identicon handler with PNG memorystream caching
/// </summary>
/// <author>Jeff Atwood http://www.codinghorror.com/, Jon Galloway http://weblogs.asp.net/jgalloway/</author>
public class IdenticonHandler : IHttpHandler
{
    private static IdenticonRenderer _renderer = new IdenticonRenderer();

    public void ProcessRequest(HttpContext context)
    {
        HttpRequest request = context.Request;
        HttpResponse response = context.Response;
        int code = request.QueryString["hash"].GetHashCode();
        int size;

        if(!int.TryParse(request["size"], out size))
        {
            size = 32;
        }

        string etag = IdenticonUtil.ETag(code, size);

        if (request.Headers["If-None-Match"] == etag)
        {
            // browser already has the image cached
            response.StatusCode = (int)HttpStatusCode.NotModified;
        }
        else
        {
            // retrieve image bytes from cache or renderer
            MemoryStream ms = HttpRuntime.Cache.Get(etag) as MemoryStream;
            if (ms == null)
            {
                ms = new MemoryStream();
                Bitmap b = _renderer.render(code, size);
                b.Save(ms, ImageFormat.Png);
                b.Dispose();
                HttpRuntime.Cache[etag] = ms;
            }
            response.AppendHeader("ETag", etag);
            response.ContentType = "image/png";
            ms.WriteTo(response.OutputStream);
        }

        HttpContext.Current.ApplicationInstance.CompleteRequest();
    }


    public bool IsReusable
    {
        get { return true; }
    }
}