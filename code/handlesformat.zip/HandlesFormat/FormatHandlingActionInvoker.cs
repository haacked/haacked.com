﻿using System;
using System.Globalization;
using System.Web.Mvc;

namespace HandlesFormat {
    public class FormatHandlingActionInvoker : ControllerActionInvoker
    {
        protected override ActionResult CreateActionResult(
            ControllerContext controllerContext,
            ActionDescriptor actionDescriptor,
            object actionReturnValue)
        {
            if (actionReturnValue == null)
            {
                return new EmptyResult();
            }

            ActionResult actionResult = actionReturnValue as ActionResult;
            if (actionResult != null)
            {
                return actionResult;
            }

            string format = (controllerContext.RouteData.Values["format"] ?? "") as string;
            switch (format)
            {
                case "":
                case "html":
                    var result = new ViewResult
                    {
                        ViewData = controllerContext.Controller.ViewData,
                        ViewName = actionDescriptor.ActionName
                    };
                    result.ViewData.Model = actionReturnValue;
                    return result;

                case "rss":
                    //TODO: RSS Result
                    break;
                case "json":
                    return new JsonResult { Data = actionReturnValue };
            }

            return new ContentResult
            {
                Content = Convert.ToString(actionReturnValue, CultureInfo.InvariantCulture)
            };
        }
    }
}
