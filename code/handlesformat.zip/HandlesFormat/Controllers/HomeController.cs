﻿using System.Web.Mvc;

namespace HandlesFormat.Controllers {
[HandleError]
public class HomeController : Controller {
  public object Index() {
    return new {Title = "HomePage", Message = "Welcome to ASP.NET MVC" };
  }
}
}
