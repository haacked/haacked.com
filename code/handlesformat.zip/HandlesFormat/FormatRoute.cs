﻿using System.Web;
using System.Web.Routing;

namespace HandlesFormat
{
    public class FormatRoute : Route
    {
        public FormatRoute(Route route)
            : base(route.Url + ".{format}", route.RouteHandler)
        {
            _originalRoute = route;
        }

        public override RouteData GetRouteData(HttpContextBase httpContext)
        {
            //HACK! Damn ugly hack.
            var context = new HttpContextWithFormat(HttpContext.Current);

            var routeData = _originalRoute.GetRouteData(context);
            var request = context.Request as HttpRequestWithFormat;
            if (!string.IsNullOrEmpty(request.Format))
            {
                routeData.Values.Add("format", request.Format);
            }

            return routeData;
        }

        public override VirtualPathData GetVirtualPath(RequestContext requestContext, RouteValueDictionary values)
        {
            var vpd = base.GetVirtualPath(requestContext, values);
            if (vpd == null)
            {
                return _originalRoute.GetVirtualPath(requestContext, values);
            }

            //HACK! Let's fix up the URL. Since "id" can be empty string, we want to check 
            // for this condition.
            string format = values["format"] as string;
            string funkyEnding = "/." + format as string;

            if (vpd.VirtualPath.EndsWith(funkyEnding))
            {
                string virtualPath = vpd.VirtualPath;
                int lastIndex = virtualPath.LastIndexOf(funkyEnding);
                virtualPath = virtualPath.Substring(0, lastIndex) + "." + format;
                vpd.VirtualPath = virtualPath;
            }

            return vpd;
        }

        private Route _originalRoute;
    }
}
