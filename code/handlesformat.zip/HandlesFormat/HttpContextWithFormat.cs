﻿using System.Web;

namespace HandlesFormat
{
    //HACK! This class is a shameful hack.
    public class HttpContextWithFormat : HttpContextWrapper
    {
        public HttpContextWithFormat(HttpContext context) : base(context) {
            _context = context;
            _request = new HttpRequestWithFormat(_context.Request);
        }

        private HttpContext _context;

        public override HttpRequestBase Request
        {
            get {
                return _request;
            }
        }
        HttpRequestBase _request;
        
    }
}
