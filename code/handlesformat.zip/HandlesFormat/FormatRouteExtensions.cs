﻿using System.Web.Mvc;
using System.Web.Routing;

namespace HandlesFormat
{
    public static class FormatRouteExtensions
    {
        public static void MapFormatRoute(this RouteCollection routes, string name, string url, object defaults) {
            Route route = new Route(url, new MvcRouteHandler()) { Defaults = new RouteValueDictionary(defaults) };

            routes.Add(new FormatRoute(route));
        }
    }
}
