﻿using System;
using System.Web.Mvc;

namespace HandlesFormat
{
    public class FormatControllerFactory : DefaultControllerFactory
    {
        protected override IController GetControllerInstance(Type controllerType)
        {
            var controller = base.GetControllerInstance(controllerType) as Controller;
            if (controller != null) {
                controller.ActionInvoker = new FormatHandlingActionInvoker();
            }
            return controller;
        }
    }
}
