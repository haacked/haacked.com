﻿using System;
using System.Web;

namespace HandlesFormat
{
    //HACK! This class is a shameful hack.
    public class HttpRequestWithFormat : HttpRequestWrapper
    {
        public HttpRequestWithFormat(HttpRequest request)
            : base(request)
        {
        }

        public override string AppRelativeCurrentExecutionFilePath
        {
            get
            {
                string filePath = base.AppRelativeCurrentExecutionFilePath;
                string extension = System.IO.Path.GetExtension(filePath);
                if (String.IsNullOrEmpty(extension))
                {
                    return filePath;
                }
                else
                {
                    Format = extension.Substring(1);
                    filePath = filePath.Substring(0, filePath.LastIndexOf(extension));
                }
                return filePath;
            }
        }

        public string Format
        {
            get;
            private set;
        }
    }
}
