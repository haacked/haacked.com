using System;
using System.Web.UI.WebControls;
using DotNetNuke.Entities.Modules;

namespace Velocit.DNN.Controls
{
	/// <summary>
	/// This is a control used to house Container options within a 
	/// container skin.  Use this when you need the container 
	/// options to fully disappear.
	/// </summary>
	public class ContainerOptions : PlaceHolder
	{
		DotNetNuke.UI.Containers.Container _container;
		PortalModuleBase _module;

		/// <summary>
		/// Initializes a new instance of the <see cref="ContainerOptions"/> class.
		/// </summary>
		public ContainerOptions()
		{
		}

		/// <summary>
		/// Gets a value indicating whether this instance is editable.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance is editable; otherwise, <c>false</c>.
		/// </value>
		protected virtual bool IsEditable
		{
			get
			{
				if(Module != null)
					return Module.IsEditable;
				return false;
			}
		}
		
		/// <summary>
		/// Returns the module contained within this container.
		/// </summary>
		PortalModuleBase Module
		{
			get
			{
				if(_module == null)
				{
					_module = DotNetNuke.UI.Containers.Container.GetPortalModuleBase(this.Container);
				}
				return _module;
			}
		}

		/// <summary>
		/// Sets the visibility.
		/// Raises the <see cref="E:System.Web.UI.Control.PreRender"/>
		/// event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> object that contains the event data.</param>
		protected override void OnPreRender(EventArgs e)
		{
			this.Visible = this.IsEditable;
			base.OnPreRender (e);
		}

		/// <summary>
		/// Returns the DNN container that contains this control if any.
		/// </summary>
		protected DotNetNuke.UI.Containers.Container Container
		{
			get
			{
				if(_container == null)
				{
					while(this.Parent != null)
					{
						DotNetNuke.UI.Containers.Container container = this.Parent as DotNetNuke.UI.Containers.Container;
						if(container != null)
						{
							_container = container;
							break;
						}
					}
				}
				return _container;
			}
		}
	}
}
