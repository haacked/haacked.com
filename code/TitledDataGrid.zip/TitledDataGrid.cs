using System;
using System.ComponentModel;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Haack.Web.Controls
{
	/// <summary>
	/// Data Grid that contains a Title Row.
	/// </summary>
	[
		ToolboxData("<{0}:TitledDataGrid runat=server></{0}:TitledDataGrid>"), 
	]
	public class TitledDataGrid : DataGrid
	{
		//This is so we can store the header style.
		private TableItemStyle headerStyle = new TableItemStyle();

		/// <summary>
		/// Gets or sets the title of the datagrid.
		/// </summary>
		/// <value></value>
		[
			Browsable(true),
			Bindable(true),
			Category("Behavior"),
			DefaultValue(null),
			Description("Creates a header row for the title")
		]
		public string Title
		{
			get
			{
				if (ViewState["Title"] != null)
					return (string) ViewState["Title"];
				return null;
			}

			set { ViewState["Title"] = value; }
		}

		/// <summary>
		/// Gets or sets the title CSS class.
		/// </summary>
		/// <value></value>
		[
			Browsable(true),
			Bindable(true),
			Category("Behavior"),
			DefaultValue(null),
			Description("Specifies the CSS Class name for the title")
		]
		public string TitleCssClass
		{
			get
			{
				if (ViewState["TitleCssClass"] != null)
					return (string)ViewState["TitleCssClass"];
				return null;
			}
			set
			{
				ViewState["TitleCssClass"] = value;
			}
		}

		/// <summary>
		/// Assigns our own render method for the header item.
		/// </summary>
		/// <param name="e">E.</param>
		protected override void OnItemCreated(DataGridItemEventArgs e)
		{
			if(ListItemType.Header == e.Item.ItemType && Title != null && Title.Length > 0)
			{
				// Copy the header style so we can replace with 
				// our title style and use the header style later.
				this.headerStyle.CopyFrom(this.HeaderStyle);
				this.HeaderStyle.Reset();

				if(TitleCssClass != null && TitleCssClass.Length > 0)
				{
					this.HeaderStyle.CssClass = TitleCssClass;
				}
				e.Item.SetRenderMethodDelegate(new RenderMethod(RenderTitle));
			}
			else
			{
				base.OnItemCreated(e);
			}
		}

		/// <summary>
		/// Renders the title as its own row.
		/// </summary>
		/// <param name="writer">Writer.</param>
		/// <param name="ctl">CTL.</param>
		protected virtual void RenderTitle(HtmlTextWriter writer, Control ctl)
		{
			// TR is on the stack writer's stack at this point...
			// It's styled using the HeaderStyle already which 
			// is why I reset the header style earlier.

			writer.AddAttribute("colspan", this.Columns.Count.ToString(CultureInfo.InvariantCulture));
			writer.AddAttribute("align", "center");
	
			writer.RenderBeginTag("TD");
			writer.Write(Title);
			writer.RenderEndTag(); // Writes </TD>
			writer.RenderEndTag(); // Writes </TR>

			// Now we add the header attributes we 
			// copied.
			this.headerStyle.AddAttributesToRender(writer);

			//Begin the header row.
			writer.RenderBeginTag("TR");

			// Render the table cells for the header row.
			foreach(Control control in ctl.Controls)
			{ 
				control.RenderControl(writer); 
			}

			// We don't need to write the </TR>. 
			// The grid will do that for us.
		}
	}
}
