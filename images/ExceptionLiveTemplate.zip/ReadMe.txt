Certain template variables have special values:

MEMBER: Value of another variable (DATATYPE) with the first character in lower case.
PROPERTYNAME: Value of another variable (DATATYPE) with the first character in upper case.