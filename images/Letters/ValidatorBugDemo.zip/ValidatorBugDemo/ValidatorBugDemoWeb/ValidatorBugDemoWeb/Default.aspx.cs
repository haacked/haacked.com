using System;
using System.Web.UI;

namespace ValidatorBugDemoWeb
{
	public partial class _Default : System.Web.UI.Page
	{

	}
}
